/**
 * Write a description of class AURA_POINT_67 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class AURA_POINT_67{
public abstract class Actor{
    // instance variables - replace the example below with your own
    private int count;
    /**
     * Constructor for objects of class AURA_POINT_67
     * Positioning of the aura point in the specified x and y coordinate
     */
    public myActor AURA_POINT_67(int x, int y)
    {
        myActor character = new myActor(); //
        addObject(character, x, y);
        return character;
    }
    public int collection()
    {
        if(intersects(){
            count+6;
        }
    }
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public int totalpoints(int y)
    {
        // put your code here
        return count;
    }
    }
}
